// ==========================================================================
// PATEL iPHONE CARE - FRONTEND CORE JAVASCRIPT
// ==========================================================================

document.addEventListener("DOMContentLoaded", () => {
    // State management
    const state = {
        currentScreen: "screen-welcome",
        selectedCategory: null,
        products: [],
        selectedProduct: null,
        salesHistory: [],
        serverUrl: "",
        isAdminAuthenticated: false,
        barcodeInputBuffer: "",
        barcodeLastKeyTime: 0
    };

    // DOM Elements
    const screens = {
        welcome: document.getElementById("screen-welcome"),
        categories: document.getElementById("screen-categories"),
        products: document.getElementById("screen-products"),
        admin: document.getElementById("screen-admin")
    };

    // --- Config & QR Code Init ---
    function initAppConfig() {
        fetch("/api/config")
            .then(res => res.json())
            .then(data => {
                state.serverUrl = data.server_url;
                document.getElementById("server-url").textContent = data.server_url;
                
                // Generate QR Code for Mobile Access
                document.getElementById("qrcode").innerHTML = "";
                new QRCode(document.getElementById("qrcode"), {
                    text: data.server_url,
                    width: 140,
                    height: 140,
                    colorDark: "#000000",
                    colorLight: "#ffffff",
                    correctLevel: QRCode.CorrectLevel.H
                });
            })
            .catch(err => {
                console.error("Config fetch failed:", err);
                document.getElementById("server-url").textContent = window.location.origin;
            });
    }
    initAppConfig();

    // --- Navigation System ---
    function navigateTo(screenId) {
        // Hide all screens
        Object.values(screens).forEach(screen => {
            screen.classList.remove("active");
        });
        
        // Show target screen
        const targetScreen = document.getElementById(screenId);
        if (targetScreen) {
            targetScreen.classList.add("active");
            state.currentScreen = screenId;
            
            // Screen-specific load operations
            if (screenId === "screen-categories") {
                clearPOSSelection();
            } else if (screenId === "screen-admin" && state.isAdminAuthenticated) {
                loadAdminDashboard();
            }
        }
    }

    // Bind back buttons
    document.querySelectorAll(".btn-back").forEach(btn => {
        btn.addEventListener("click", () => {
            const target = btn.getAttribute("data-target");
            navigateTo(target);
        });
    });

    // Welcome Screen triggers
    document.getElementById("btn-browse").addEventListener("click", () => {
        navigateTo("screen-categories");
    });

    document.getElementById("btn-admin-login-trigger").addEventListener("click", () => {
        navigateTo("screen-admin");
    });

    // --- Categories Screen ---
    document.querySelectorAll(".category-card").forEach(card => {
        card.addEventListener("click", () => {
            const cat = card.getAttribute("data-category");
            state.selectedCategory = cat;
            
            // Set Header Title
            const titleElement = document.getElementById("category-title");
            titleElement.textContent = card.querySelector("h3").textContent;
            
            // Navigate to products and fetch
            navigateTo("screen-products");
            document.getElementById("search-input").value = "";
            document.getElementById("btn-search-clear").style.display = "none";
            fetchProducts(cat);
        });
    });

    // --- Products & Search Screen ---
    const searchInput = document.getElementById("search-input");
    const clearSearchBtn = document.getElementById("btn-search-clear");

    searchInput.addEventListener("input", (e) => {
        const query = e.target.value;
        clearSearchBtn.style.display = query ? "block" : "none";
        fetchProducts(state.selectedCategory, query);
    });

    clearSearchBtn.addEventListener("click", () => {
        searchInput.value = "";
        clearSearchBtn.style.display = "none";
        fetchProducts(state.selectedCategory);
    });

    function fetchProducts(category, query = "") {
        let url = `/api/products?category=${category}`;
        if (query) {
            url += `&query=${encodeURIComponent(query)}`;
        }
        
        fetch(url)
            .then(res => res.json())
            .then(products => {
                state.products = products;
                renderProductsList(products);
            })
            .catch(err => console.error("Error loading products:", err));
    }

    function renderProductsList(products) {
        const container = document.getElementById("products-list");
        const emptyMsg = document.getElementById("no-products-msg");
        container.innerHTML = "";
        
        if (products.length === 0) {
            emptyMsg.classList.remove("hidden");
            return;
        }
        emptyMsg.classList.add("hidden");
        
        products.forEach(p => {
            const card = document.createElement("div");
            card.className = `glass-panel-interactive product-item-card ${state.selectedProduct && state.selectedProduct.id === p.id ? 'selected' : ''}`;
            card.dataset.id = p.id;
            
            const isLowStock = p.stock <= 2;
            const stockClass = isLowStock ? 'stock-warning' : '';
            const stockIcon = isLowStock ? 'fa-triangle-exclamation' : 'fa-cubes';
            
            card.innerHTML = `
                <div class="prod-header">
                    <h3>${p.name}</h3>
                    <div class="prod-price">₹${p.price.toLocaleString('en-IN', {minimumFractionDigits: 2})}</div>
                </div>
                <div class="prod-meta">
                    <div class="meta-pill ${stockClass}">
                        <i class="fa-solid ${stockIcon}"></i> Stock: ${p.stock}
                    </div>
                    <div class="meta-pill">
                        <i class="fa-solid fa-tags"></i> Rack: ${p.rack_no || '-'}
                    </div>
                    <div class="meta-pill">
                        <i class="fa-solid fa-box-open"></i> Box: ${p.box_no || '-'}
                    </div>
                    <div class="meta-pill">
                        <i class="fa-solid fa-barcode"></i> Bar: ${p.barcode ? 'Yes' : 'No'}
                    </div>
                </div>
            `;
            
            card.addEventListener("click", () => {
                selectProduct(p);
                // Highlight active card
                document.querySelectorAll(".product-item-card").forEach(c => c.classList.remove("selected"));
                card.classList.add("selected");
            });
            
            container.appendChild(card);
        });
    }

    function selectProduct(product) {
        state.selectedProduct = product;
        const summaryPanel = document.getElementById("pos-selection-summary");
        
        if (product) {
            summaryPanel.classList.remove("hidden");
            document.getElementById("pos-selected-name").textContent = product.name;
            document.getElementById("pos-selected-meta").textContent = `Price: ₹${product.price.toLocaleString('en-IN')} | Rack: ${product.rack_no || '-'} | Box: ${product.box_no || '-'} | Available: ${product.stock}`;
        } else {
            clearPOSSelection();
        }
    }

    function clearPOSSelection() {
        state.selectedProduct = null;
        document.getElementById("pos-selection-summary").classList.add("hidden");
        document.querySelectorAll(".product-item-card").forEach(c => c.classList.remove("selected"));
    }

    // Next button on checkout panel
    document.getElementById("btn-checkout-next").addEventListener("click", () => {
        if (!state.selectedProduct) return;
        openCheckoutModal(state.selectedProduct);
    });


    // --- Checkout Modal ---
    const modalCheckout = document.getElementById("modal-checkout");
    const checkoutPriceInput = document.getElementById("checkout-price");
    const checkoutQtyInput = document.getElementById("checkout-quantity");
    const checkoutCustNameInput = document.getElementById("checkout-customer-name");
    const checkoutGstInput = document.getElementById("checkout-gst");
    const grandTotalSpan = document.getElementById("checkout-grand-total");

    function openCheckoutModal(product) {
        document.getElementById("checkout-product-name").textContent = product.name;
        document.getElementById("checkout-rack-no").textContent = product.rack_no || '-';
        document.getElementById("checkout-box-no").textContent = product.box_no || '-';
        document.getElementById("checkout-stock-no").textContent = product.stock;
        
        checkoutPriceInput.value = product.price;
        checkoutQtyInput.value = 1;
        checkoutQtyInput.max = product.stock;
        checkoutCustNameInput.value = "";
        checkoutGstInput.value = "";
        
        updateCheckoutTotal();
        modalCheckout.classList.remove("hidden");
    }

    function updateCheckoutTotal() {
        const price = parseFloat(checkoutPriceInput.value) || 0;
        const qty = parseInt(checkoutQtyInput.value) || 1;
        const total = price * qty;
        grandTotalSpan.textContent = `₹${total.toLocaleString('en-IN', {minimumFractionDigits: 2})}`;
    }

    checkoutPriceInput.addEventListener("input", updateCheckoutTotal);
    checkoutQtyInput.addEventListener("input", updateCheckoutTotal);

    // Buy / print button click
    document.getElementById("btn-buy-submit").addEventListener("click", () => {
        if (!state.selectedProduct) return;
        
        const price = parseFloat(checkoutPriceInput.value);
        const qty = parseInt(checkoutQtyInput.value);
        const customerName = checkoutCustNameInput.value.strip ? checkoutCustNameInput.value.strip() : checkoutCustNameInput.value.trim();
        const gstNum = checkoutGstInput.value.strip ? checkoutGstInput.value.strip() : checkoutGstInput.value.trim();
        
        if (isNaN(price) || price < 0) {
            alert("Please enter a valid price.");
            return;
        }
        if (isNaN(qty) || qty <= 0) {
            alert("Quantity must be at least 1.");
            return;
        }
        if (qty > state.selectedProduct.stock) {
            alert(`Insufficient stock. Only ${state.selectedProduct.stock} left.`);
            return;
        }

        const salePayload = {
            product_id: state.selectedProduct.id,
            quantity: qty,
            price: price,
            customer_name: customerName || "Walk-in Customer",
            gst_number: gstNum
        };

        // Create Sale Record
        fetch("/api/sales", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(salePayload)
        })
        .then(res => res.json())
        .then(data => {
            if (data.error) {
                alert(data.error);
                return;
            }
            // Close Checkout modal
            modalCheckout.classList.add("hidden");
            // Refresh screen products
            fetchProducts(state.selectedCategory, searchInput.value);
            // Open print receipt modal with data
            openPrintReceiptModal(data.sale);
        })
        .catch(err => {
            console.error("Sale submission error:", err);
            alert("Failed to complete purchase. Check server connection.");
        });
    });


    // --- Invoice Receipt Preview & Print Modal ---
    const modalPrint = document.getElementById("modal-print-confirm");

    function openPrintReceiptModal(sale) {
        document.getElementById("receipt-id").textContent = `#${String(sale.id).padStart(4, '0')}`;
        document.getElementById("receipt-date").textContent = formatDate(sale.sale_date);
        document.getElementById("receipt-time").textContent = formatTime(sale.sale_time);
        document.getElementById("receipt-customer").textContent = sale.customer_name;
        
        const gstRow = document.getElementById("receipt-customer-gst-row");
        if (sale.gst_number) {
            gstRow.classList.remove("hidden");
            document.getElementById("receipt-customer-gst").textContent = sale.gst_number;
        } else {
            gstRow.classList.add("hidden");
        }
        
        document.getElementById("receipt-item-name").textContent = sale.product_name;
        document.getElementById("receipt-item-qty").textContent = sale.quantity;
        document.getElementById("receipt-item-price").textContent = `₹${sale.price.toLocaleString('en-IN', {minimumFractionDigits:2})}`;
        
        const totalFormatted = `₹${sale.total_price.toLocaleString('en-IN', {minimumFractionDigits:2})}`;
        document.getElementById("receipt-item-total").textContent = totalFormatted;
        document.getElementById("receipt-subtotal").textContent = totalFormatted;
        document.getElementById("receipt-grand-total-val").textContent = totalFormatted;
        
        modalPrint.classList.remove("hidden");
    }

    // Trigger Print
    document.getElementById("btn-print-action").addEventListener("click", () => {
        window.print();
        modalPrint.classList.add("hidden");
        clearPOSSelection();
    });


    // --- Helper date format utilities ---
    function formatDate(dateStr) {
        // YYYY-MM-DD to DD-MM-YYYY
        const parts = dateStr.split('-');
        if (parts.length === 3) {
            return `${parts[2]}-${parts[1]}-${parts[0]}`;
        }
        return dateStr;
    }

    function formatTime(timeStr) {
        // HH:MM:SS to 12 hour format
        const parts = timeStr.split(':');
        if (parts.length >= 2) {
            let hr = parseInt(parts[0]);
            const min = parts[1];
            const ampm = hr >= 12 ? 'PM' : 'AM';
            hr = hr % 12;
            hr = hr ? hr : 12; // 0 should be 12
            return `${hr}:${min} ${ampm}`;
        }
        return timeStr;
    }


    // --- Admin Authentication (Tabs, Password & Biometric) ---
    const adminAuthContainer = document.getElementById("admin-auth-container");
    const adminDashboardContainer = document.getElementById("admin-dashboard-container");

    // Auth tab toggling
    document.querySelectorAll(".auth-tab").forEach(tab => {
        tab.addEventListener("click", () => {
            document.querySelectorAll(".auth-tab").forEach(t => t.classList.remove("active"));
            document.querySelectorAll(".auth-panel").forEach(p => p.classList.remove("active"));
            
            tab.classList.add("active");
            const targetPanel = document.getElementById(`auth-panel-${tab.getAttribute("data-tab")}`);
            if (targetPanel) targetPanel.classList.add("active");
        });
    });

    // Password visiblity toggle
    document.getElementById("btn-toggle-pwd").addEventListener("click", () => {
        const pwdInput = document.getElementById("admin-password");
        const icon = document.querySelector("#btn-toggle-pwd i");
        if (pwdInput.type === "password") {
            pwdInput.type = "text";
            icon.classList.replace("fa-eye", "fa-eye-slash");
        } else {
            pwdInput.type = "password";
            icon.classList.replace("fa-eye-slash", "fa-eye");
        }
    });

    // Password login submit
    document.getElementById("btn-login-submit").addEventListener("click", submitPasswordAuth);
    document.getElementById("admin-password").addEventListener("keypress", (e) => {
        if (e.key === "Enter") submitPasswordAuth();
    });

    function submitPasswordAuth() {
        const pwd = document.getElementById("admin-password").value;
        if (pwd === "patel mobiles") {
            grantAdminAccess();
        } else {
            alert("Incorrect Admin Password. Access Denied.");
        }
    }

    // Biometric Fingerprint simulation
    const scanner = document.getElementById("biometric-scanner");
    const statusText = document.getElementById("scan-status-text");
    let scanTimeout = null;

    scanner.addEventListener("mousedown", startFingerprintScan);
    scanner.addEventListener("touchstart", (e) => {
        e.preventDefault(); // Prevents double triggers on mobile
        startFingerprintScan();
    });

    window.addEventListener("mouseup", cancelFingerprintScan);
    window.addEventListener("touchend", cancelFingerprintScan);

    function startFingerprintScan() {
        if (state.isAdminAuthenticated) return;
        
        scanner.className = "fingerprint-scanner scanning";
        statusText.textContent = "Scanning... Hold still";
        
        scanTimeout = setTimeout(() => {
            scanner.className = "fingerprint-scanner success";
            statusText.textContent = "Access Granted! Loading system...";
            
            // Vibrate phone if available
            if (navigator.vibrate) {
                navigator.vibrate([100, 50, 100]);
            }
            
            setTimeout(() => {
                grantAdminAccess();
            }, 1000);
            
        }, 1800); // Hold for 1.8 seconds
    }

    function cancelFingerprintScan() {
        if (state.isAdminAuthenticated) return;
        if (scanner.classList.contains("scanning")) {
            scanner.className = "fingerprint-scanner";
            statusText.textContent = "Scan interrupted. Hold finger on scanner to unlock";
            clearTimeout(scanTimeout);
        }
    }

    function grantAdminAccess() {
        state.isAdminAuthenticated = true;
        adminAuthContainer.classList.add("hidden");
        adminDashboardContainer.classList.remove("hidden");
        
        // Clear forms
        document.getElementById("admin-password").value = "";
        
        loadAdminDashboard();
    }

    // --- Admin Dashboard logic ---
    function loadAdminDashboard() {
        loadInventoryTable();
        loadSalesHistoryTable();
    }

    // Admin Dashboard tabs
    document.querySelectorAll(".admin-tab").forEach(tab => {
        tab.addEventListener("click", () => {
            document.querySelectorAll(".admin-tab").forEach(t => t.classList.remove("active"));
            document.querySelectorAll(".admin-tab-panel").forEach(p => p.classList.remove("active"));
            
            tab.classList.add("active");
            const targetPanel = document.getElementById(`admin-panel-${tab.getAttribute("data-tab")}`);
            if (targetPanel) targetPanel.classList.add("active");
        });
    });

    // --- Inventory Table Management ---
    let allInventoryProducts = [];

    function loadInventoryTable() {
        fetch("/api/products?category=all")
            .then(res => res.json())
            .then(products => {
                allInventoryProducts = products;
                renderInventoryTable(products);
            })
            .catch(err => console.error("Error loading inventory:", err));
    }

    function renderInventoryTable(products) {
        const tbody = document.getElementById("inventory-table-body");
        tbody.innerHTML = "";
        
        products.forEach(p => {
            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td><span class="label-category">${capitalize(p.category)}</span></td>
                <td><strong>${p.name}</strong></td>
                <td>${p.stock}</td>
                <td>₹${p.price.toLocaleString('en-IN', {minimumFractionDigits: 2})}</td>
                <td>${p.rack_no || '-'}</td>
                <td>${p.box_no || '-'}</td>
                <td><code>${p.barcode || '-'}</code></td>
                <td>
                    <div class="actions-cell">
                        <button class="btn-icon btn-edit" data-id="${p.id}" title="Edit"><i class="fa-solid fa-pen-to-square"></i></button>
                        <button class="btn-icon btn-remove" data-id="${p.id}" title="Delete"><i class="fa-solid fa-trash"></i></button>
                    </div>
                </td>
            `;
            
            // Edit trigger
            tr.querySelector(".btn-edit").addEventListener("click", () => {
                openProductModal(p);
            });
            
            // Delete trigger
            tr.querySelector(".btn-remove").addEventListener("click", () => {
                if (confirm(`Are you sure you want to delete ${p.name}?`)) {
                    deleteProduct(p.id);
                }
            });
            
            tbody.appendChild(tr);
        });
    }

    // Inventory Table Live Search
    document.getElementById("admin-search-input").addEventListener("input", (e) => {
        const query = e.target.value.toLowerCase().trim();
        if (!query) {
            renderInventoryTable(allInventoryProducts);
            return;
        }
        
        const filtered = allInventoryProducts.filter(p => {
            return (p.name.toLowerCase().includes(query) || 
                    p.category.toLowerCase().includes(query) || 
                    (p.barcode && p.barcode.toLowerCase().includes(query)) || 
                    (p.rack_no && p.rack_no.toLowerCase().includes(query)) || 
                    (p.box_no && p.box_no.toLowerCase().includes(query)));
        });
        renderInventoryTable(filtered);
    });

    // Add product trigger
    document.getElementById("btn-add-product-trigger").addEventListener("click", () => {
        openProductModal(null);
    });

    // Add/Edit Product Modal UI Operations
    const modalProduct = document.getElementById("modal-product");
    const productForm = document.getElementById("product-form");

    function openProductModal(product = null) {
        productForm.reset();
        
        if (product) {
            document.getElementById("product-modal-title").textContent = "Edit Product";
            document.getElementById("product-edit-id").value = product.id;
            document.getElementById("product-category").value = product.category;
            document.getElementById("product-name").value = product.name;
            document.getElementById("product-stock").value = product.stock;
            document.getElementById("product-price").value = product.price;
            document.getElementById("product-rack").value = product.rack_no || "";
            document.getElementById("product-box").value = product.box_no || "";
            document.getElementById("product-barcode").value = product.barcode || "";
        } else {
            document.getElementById("product-modal-title").textContent = "Add New Product";
            document.getElementById("product-edit-id").value = "";
        }
        
        modalProduct.classList.remove("hidden");
    }

    productForm.addEventListener("submit", (e) => {
        e.preventDefault();
        
        const editId = document.getElementById("product-edit-id").value;
        const payload = {
            category: document.getElementById("product-category").value,
            name: document.getElementById("product-name").value.trim(),
            stock: parseInt(document.getElementById("product-stock").value) || 0,
            price: parseFloat(document.getElementById("product-price").value) || 0.0,
            rack_no: document.getElementById("product-rack").value.trim(),
            box_no: document.getElementById("product-box").value.trim(),
            barcode: document.getElementById("product-barcode").value.trim()
        };
        
        const url = editId ? `/api/products/${editId}` : "/api/products";
        const method = editId ? "PUT" : "POST";
        
        fetch(url, {
            method: method,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        })
        .then(res => res.json())
        .then(data => {
            if (data.error) {
                alert(data.error);
                return;
            }
            modalProduct.classList.add("hidden");
            loadInventoryTable();
        })
        .catch(err => {
            console.error("Error saving product:", err);
            alert("Failed to save product details.");
        });
    });

    function deleteProduct(productId) {
        fetch(`/api/products/${productId}`, {
            method: "DELETE"
        })
        .then(res => res.json())
        .then(data => {
            loadInventoryTable();
        })
        .catch(err => {
            console.error("Error deleting product:", err);
            alert("Failed to delete product.");
        });
    }


    // --- Sales History Table Management ---
    function loadSalesHistoryTable() {
        fetch("/api/sales")
            .then(res => res.json())
            .then(sales => {
                state.salesHistory = sales;
                renderSalesHistoryTable(sales);
            })
            .catch(err => console.error("Error loading sales history:", err));
    }

    function renderSalesHistoryTable(sales) {
        const tbody = document.getElementById("sales-table-body");
        tbody.innerHTML = "";
        
        let todaySalesSum = 0;
        let todayItemsSum = 0;
        
        const todayStr = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
        
        sales.forEach(s => {
            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td><code>#${String(s.id).padStart(4, '0')}</code></td>
                <td>${formatDate(s.sale_date)} <span class="time-lbl">${formatTime(s.sale_time)}</span></td>
                <td><strong>${s.product_name}</strong></td>
                <td>${s.customer_name}</td>
                <td>${s.gst_number ? `<code>${s.gst_number}</code>` : '-'}</td>
                <td>${s.quantity}</td>
                <td>₹${s.price.toLocaleString('en-IN')}</td>
                <td><strong>₹${s.total_price.toLocaleString('en-IN', {minimumFractionDigits: 2})}</strong></td>
            `;
            tbody.appendChild(tr);
            
            // Calculate today stats
            if (s.sale_date === todayStr) {
                todaySalesSum += s.total_price;
                todayItemsSum += s.quantity;
            }
        });
        
        document.getElementById("today-sales-val").textContent = `₹${todaySalesSum.toLocaleString('en-IN', {minimumFractionDigits: 2})}`;
        document.getElementById("today-items-val").textContent = todayItemsSum;
    }


    // --- Barcode Scanner Logic ---
    let cameraScannerInstance = null;
    const modalScanner = document.getElementById("modal-scanner");
    const modalQuickAdd = document.getElementById("modal-quick-add");

    // Camera Scan Trigger (Category Screen or Product edit Barcode trigger)
    let barcodeTargetInput = null; // Stores target if we scan to fill admin form
    
    document.getElementById("btn-scan-trigger").addEventListener("click", () => {
        barcodeTargetInput = null;
        openCameraScanner();
    });

    document.getElementById("btn-scan-product-barcode").addEventListener("click", () => {
        barcodeTargetInput = document.getElementById("product-barcode");
        openCameraScanner();
    });

    document.getElementById("btn-close-scanner").addEventListener("click", closeCameraScanner);

    function openCameraScanner() {
        modalScanner.classList.remove("hidden");
        
        // Start camera reader using html5-qrcode
        if (typeof Html5QrcodeScanner !== "undefined") {
            cameraScannerInstance = new Html5Qrcode("interactive-scanner");
            const config = { fps: 10, qrbox: { width: 250, height: 120 } };
            
            cameraScannerInstance.start(
                { facingMode: "environment" },
                config,
                onBarcodeDetected,
                onScanError
            )
            .catch(err => {
                console.error("Camera access error:", err);
                statusText.textContent = "Camera access denied. Please enter barcode manually.";
            });
        } else {
            console.error("Html5Qrcode library not loaded.");
        }
    }

    function closeCameraScanner() {
        modalScanner.classList.add("hidden");
        if (cameraScannerInstance) {
            cameraScannerInstance.stop()
                .then(() => {
                    cameraScannerInstance = null;
                })
                .catch(err => console.error("Error stopping scanner:", err));
        }
    }

    function onBarcodeDetected(decodedText) {
        // Play scan beep if possible
        playBeepSound();
        
        closeCameraScanner();
        handleBarcodeScannedResult(decodedText);
    }

    function onScanError(err) {
        // Suppress logs to avoid console clutter
    }

    // Manual Barcode scanner input submit
    document.getElementById("btn-manual-scan-submit").addEventListener("click", () => {
        const val = document.getElementById("manual-scan-input").value.trim();
        if (val) {
            document.getElementById("manual-scan-input").value = "";
            closeCameraScanner();
            handleBarcodeScannedResult(val);
        }
    });
    
    document.getElementById("manual-scan-input").addEventListener("keypress", (e) => {
        if (e.key === "Enter") {
            const val = e.target.value.trim();
            if (val) {
                e.target.value = "";
                closeCameraScanner();
                handleBarcodeScannedResult(val);
            }
        }
    });

    // Handle the scanned barcode string
    function handleBarcodeScannedResult(barcode) {
        // Case 1: Filling barcode in Admin form
        if (barcodeTargetInput) {
            barcodeTargetInput.value = barcode;
            return;
        }
        
        // Case 2: Checkout Scan (General lookup)
        fetch(`/api/products/barcode/${encodeURIComponent(barcode)}`)
            .then(res => {
                if (res.status === 404) {
                    // Open Quick Add Modal
                    openQuickAddModal(barcode);
                    return null;
                }
                return res.json();
            })
            .then(product => {
                if (!product) return;
                // Directly open checkout modal
                state.selectedProduct = product;
                openCheckoutModal(product);
            })
            .catch(err => console.error("Error looking up barcode:", err));
    }

    // --- Barcode Quick Add Modal ---
    function openQuickAddModal(barcode) {
        document.getElementById("quick-add-barcode-val").textContent = barcode;
        document.getElementById("quick-add-form").reset();
        modalQuickAdd.classList.remove("hidden");
    }

    document.getElementById("quick-add-form").addEventListener("submit", (e) => {
        e.preventDefault();
        
        const barcode = document.getElementById("quick-add-barcode-val").textContent;
        const name = document.getElementById("quick-add-name").value.trim();
        const category = document.getElementById("quick-add-category").value;
        const stock = parseInt(document.getElementById("quick-add-stock").value) || 1;
        const price = parseFloat(document.getElementById("quick-add-price").value) || 0.0;
        const rack = document.getElementById("quick-add-rack").value.trim();
        const box = document.getElementById("quick-add-box").value.trim();

        const payload = {
            category: category,
            name: name,
            stock: stock,
            price: price,
            rack_no: rack,
            box_no: box,
            barcode: barcode
        };

        // Add item to database
        fetch("/api/products", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        })
        .then(res => res.json())
        .then(data => {
            if (data.error) {
                alert(data.error);
                return;
            }
            modalQuickAdd.classList.add("hidden");
            
            // Fetch product and initiate purchase
            const newProduct = {
                id: data.id,
                name: name,
                category: category,
                stock: stock,
                price: price,
                rack_no: rack,
                box_no: box,
                barcode: barcode
            };
            
            state.selectedProduct = newProduct;
            openCheckoutModal(newProduct);
        })
        .catch(err => {
            console.error("Error doing barcode quick add:", err);
            alert("Failed to quickly register product.");
        });
    });


    // --- Global Keyboard-Emulated Barcode Scanner Listener ---
    // Physical USB/Bluetooth barcode readers act as keyboards typing numbers very fast and ending with "Enter".
    window.addEventListener("keydown", (e) => {
        // Skip global capture if active in input fields unless it's body or screens
        const target = e.target.tagName.toLowerCase();
        if (target === "input" || target === "textarea" || target === "select") {
            // Except for manual scan inputs
            if (e.target.id !== "manual-scan-input" && e.target.id !== "product-barcode") {
                return; 
            }
        }
        
        const currentTime = new Date().getTime();
        
        // If elapsed time is short, it's typed by barcode reader
        if (currentTime - state.barcodeLastKeyTime < 35) {
            if (e.key === "Enter") {
                const scannedBarcode = state.barcodeInputBuffer;
                state.barcodeInputBuffer = "";
                
                if (scannedBarcode.length > 2) {
                    playBeepSound();
                    handleBarcodeScannedResult(scannedBarcode);
                }
            } else if (e.key !== "Shift" && e.key !== "Control" && e.key !== "Alt") {
                state.barcodeInputBuffer += e.key;
            }
        } else {
            // Reset buffer if delay is too long (implies human typing)
            if (e.key !== "Enter" && e.key !== "Shift" && e.key !== "Control" && e.key !== "Alt") {
                state.barcodeInputBuffer = e.key;
            }
        }
        
        state.barcodeLastKeyTime = currentTime;
    });


    // --- Utility helper functions ---
    function capitalize(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }

    function playBeepSound() {
        try {
            // Generate synthetic scanner beep via Web Audio API
            const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
            const oscillator = audioCtx.createOscillator();
            const gainNode = audioCtx.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(audioCtx.destination);
            
            oscillator.type = "sine";
            oscillator.frequency.setValueAtTime(1046.50, audioCtx.currentTime); // C6 note (classic scanner beep)
            gainNode.gain.setValueAtTime(0.08, audioCtx.currentTime);
            
            oscillator.start();
            oscillator.stop(audioCtx.currentTime + 0.08); // beep duration 80ms
        } catch (e) {
            console.log("Audio beep failed: ", e);
        }
    }


    // --- Close Modals binding ---
    document.querySelectorAll(".btn-close-modal").forEach(btn => {
        btn.addEventListener("click", () => {
            modalCheckout.classList.add("hidden");
            modalPrint.classList.add("hidden");
            modalProduct.classList.add("hidden");
            modalQuickAdd.classList.add("hidden");
        });
    });

    // Close on overlay click
    window.addEventListener("click", (e) => {
        if (e.target === modalCheckout) modalCheckout.classList.add("hidden");
        if (e.target === modalPrint) modalPrint.classList.add("hidden");
        if (e.target === modalProduct) modalProduct.classList.add("hidden");
        if (e.target === modalQuickAdd) modalQuickAdd.classList.add("hidden");
    });
});
