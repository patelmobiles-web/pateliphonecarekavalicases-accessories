import os
import csv
import socket
from datetime import datetime
from flask import Flask, request, jsonify, render_template, send_from_directory
from database import get_db_connection, init_db

app = Flask(__name__, template_folder='templates', static_folder='static')

# Ensure directories exist
os.makedirs(os.path.join(app.root_path, 'templates'), exist_ok=True)
os.makedirs(os.path.join(app.root_path, 'static', 'css'), exist_ok=True)
os.makedirs(os.path.join(app.root_path, 'static', 'js'), exist_ok=True)

CSV_FILE_PATH = os.path.join(app.root_path, 'sales_history.csv')

# Initialize DB on start
init_db()

def get_local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # Doesn't need to be reachable, just gets the interface IP
        s.connect(('10.255.255.255', 1))
        IP = s.getsockname()[0]
    except Exception:
        IP = '127.0.0.1'
    finally:
        s.close()
    return IP

def normalize_text(text):
    if not text:
        return ""
    text = text.lower().strip()
    # Replace common symbols/words
    text = text.replace('1+', 'oneplus')
    # Replace word "op" with "oppo"
    import re
    text = re.sub(r'\bop\b', 'oppo', text)
    return text

def get_product_brand(product_name):
    p_lower = product_name.lower()
    if any(x in p_lower for x in ['reno', 'f19', 'f21', 'a78', 'oppo']):
        return 'oppo'
    if any(x in p_lower for x in ['realme', 'narzo', 'x7', '7 pro', '8 pro', '9 pro', '10 4g', '11']):
        return 'realme'
    if p_lower in ['7 pro', '8', '8 pro', '9 4g', '9 5g', '9 pro+', '10 4g', '11', 'narzo 60', 'realme x7']:
        return 'realme'
    if 'nord' in p_lower or '1+' in p_lower or 'oneplus' in p_lower:
        return 'oneplus'
    return ''

def append_to_csv(sale_data):
    file_exists = os.path.exists(CSV_FILE_PATH)
    with open(CSV_FILE_PATH, mode='a', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow([
                'Sale ID', 'Date', 'Time', 'Customer Name', 'GST Number',
                'Product ID', 'Product Name', 'Quantity', 'Price', 'Total Price'
            ])
        writer.writerow([
            sale_data['id'],
            sale_data['sale_date'],
            sale_data['sale_time'],
            sale_data.get('customer_name', ''),
            sale_data.get('gst_number', ''),
            sale_data.get('product_id', ''),
            sale_data['product_name'],
            sale_data['quantity'],
            sale_data['price'],
            sale_data['total_price']
        ])

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/config')
def get_config():
    local_ip = get_local_ip()
    port = 5000
    server_url = f"http://{local_ip}:{port}"
    return jsonify({
        'local_ip': local_ip,
        'server_url': server_url
    })

@app.route('/api/products', methods=['GET'])
def get_products():
    category = request.args.get('category')
    query = request.args.get('query')
    
    conn = get_db_connection()
    if category and category != 'all':
        cursor = conn.execute('SELECT * FROM products WHERE category = ?', (category,))
    else:
        cursor = conn.execute('SELECT * FROM products')
    products = [dict(row) for row in cursor.fetchall()]
    conn.close()
    
    if not query:
        return jsonify(products)
        
    query_norm = normalize_text(query)
    query_words = [w for w in query_norm.split() if w]
    
    matched_results = []
    for p in products:
        p_name = p['name']
        p_norm = normalize_text(p_name)
        brand = get_product_brand(p_name)
        
        # Build searchable variations
        searchable_terms = [p_norm]
        if brand:
            searchable_terms.append(brand + " " + p_norm)
            if brand == 'oppo':
                searchable_terms.append("op " + p_norm)
            elif brand == 'oneplus':
                searchable_terms.append("1+ " + p_norm)
                
        # Scoring match
        score = 0
        substring_match = False
        for term in searchable_terms:
            if query_norm in term:
                substring_match = True
                score += (len(query_norm) / len(term)) * 100
                break
                
        matched_words = 0
        for qw in query_words:
            word_match = False
            for term in searchable_terms:
                if qw in term:
                    word_match = True
                    break
            if word_match:
                matched_words += 1
                
        if substring_match or (matched_words == len(query_words) and len(query_words) > 0):
            word_score = (matched_words / len(query_words)) * 50 if len(query_words) > 0 else 0
            p['score'] = score + word_score
            matched_results.append(p)
            
    matched_results.sort(key=lambda x: x.get('score', 0), reverse=True)
    for r in matched_results:
        r.pop('score', None)
        
    return jsonify(matched_results)

@app.route('/api/products/barcode/<barcode>', methods=['GET'])
def get_product_by_barcode(barcode):
    conn = get_db_connection()
    cursor = conn.execute('SELECT * FROM products WHERE barcode = ?', (barcode,))
    product = cursor.fetchone()
    conn.close()
    if product:
        return jsonify(dict(product))
    return jsonify(None), 404

@app.route('/api/products', methods=['POST'])
def add_product():
    data = request.json
    category = data.get('category')
    name = data.get('name')
    stock = int(data.get('stock', 0))
    price = float(data.get('price', 0.0))
    rack_no = data.get('rack_no')
    box_no = data.get('box_no')
    barcode = data.get('barcode')
    
    if not category or not name:
        return jsonify({'error': 'Category and Name are required'}), 400
        
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO products (category, name, stock, price, rack_no, box_no, barcode)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (category, name, stock, price, rack_no, box_no, barcode if barcode else None))
        conn.commit()
        product_id = cursor.lastrowid
        conn.close()
        return jsonify({'id': product_id, 'message': 'Product added successfully'}), 201
    except sqlite3.IntegrityError as e:
        conn.close()
        return jsonify({'error': f'Product with this name or barcode already exists: {str(e)}'}), 400

@app.route('/api/products/<int:product_id>', methods=['PUT'])
def update_product(product_id):
    data = request.json
    category = data.get('category')
    name = data.get('name')
    stock = int(data.get('stock', 0))
    price = float(data.get('price', 0.0))
    rack_no = data.get('rack_no')
    box_no = data.get('box_no')
    barcode = data.get('barcode')
    
    conn = get_db_connection()
    try:
        conn.execute('''
            UPDATE products
            SET category = ?, name = ?, stock = ?, price = ?, rack_no = ?, box_no = ?, barcode = ?
            WHERE id = ?
        ''', (category, name, stock, price, rack_no, box_no, barcode if barcode else None, product_id))
        conn.commit()
        conn.close()
        return jsonify({'message': 'Product updated successfully'}), 200
    except sqlite3.IntegrityError as e:
        conn.close()
        return jsonify({'error': f'Name or Barcode already exists: {str(e)}'}), 400

@app.route('/api/products/<int:product_id>', methods=['DELETE'])
def delete_product(product_id):
    conn = get_db_connection()
    conn.execute('DELETE FROM products WHERE id = ?', (product_id,))
    conn.commit()
    conn.close()
    return jsonify({'message': 'Product deleted successfully'}), 200

@app.route('/api/sales', methods=['POST'])
def record_sale():
    data = request.json
    product_id = data.get('product_id')
    product_name = data.get('product_name')  # Used if product is not in DB yet (direct scan bypass)
    quantity = int(data.get('quantity', 1))
    price = float(data.get('price', 0.0))
    customer_name = data.get('customer_name', 'Walk-in Customer')
    gst_number = data.get('gst_number', '')
    
    now = datetime.now()
    sale_date = now.strftime('%Y-%m-%d')
    sale_time = now.strftime('%H:%M:%S')
    total_price = price * quantity
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Deduct stock if product exists in database
    if product_id:
        cursor.execute('SELECT stock, name FROM products WHERE id = ?', (product_id,))
        prod = cursor.fetchone()
        if prod:
            current_stock = prod['stock']
            product_name = prod['name']
            if current_stock < quantity:
                conn.close()
                return jsonify({'error': f'Insufficient stock. Available: {current_stock}'}), 400
                
            cursor.execute('UPDATE products SET stock = stock - ? WHERE id = ?', (quantity, product_id))
            
    # Record sale
    cursor.execute('''
        INSERT INTO sales (sale_date, sale_time, customer_name, gst_number, product_id, product_name, quantity, price, total_price)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (sale_date, sale_time, customer_name, gst_number, product_id, product_name, quantity, price, total_price))
    
    sale_id = cursor.lastrowid
    conn.commit()
    conn.close()
    
    sale_data = {
        'id': sale_id,
        'sale_date': sale_date,
        'sale_time': sale_time,
        'customer_name': customer_name,
        'gst_number': gst_number,
        'product_id': product_id,
        'product_name': product_name,
        'quantity': quantity,
        'price': price,
        'total_price': total_price
    }
    
    # Save/Append to CSV
    try:
        append_to_csv(sale_data)
    except Exception as e:
        print(f"Error writing to CSV: {e}")
        
    return jsonify({'message': 'Sale completed successfully', 'sale': sale_data}), 201

@app.route('/api/sales', methods=['GET'])
def get_sales_history():
    conn = get_db_connection()
    cursor = conn.execute('SELECT * FROM sales ORDER BY id DESC')
    sales = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return jsonify(sales)

@app.route('/api/sales/export')
def export_sales():
    if not os.path.exists(CSV_FILE_PATH):
        # Create empty CSV with headers
        with open(CSV_FILE_PATH, mode='w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow([
                'Sale ID', 'Date', 'Time', 'Customer Name', 'GST Number',
                'Product ID', 'Product Name', 'Quantity', 'Price', 'Total Price'
            ])
            
    return send_from_directory(
        directory=app.root_path,
        path='sales_history.csv',
        as_attachment=True,
        download_name=f"sales_history_{datetime.now().strftime('%Y-%m-%d')}.csv"
    )

if __name__ == '__main__':
    # Serve on all interfaces so mobile can access
    app.run(host='0.0.0.0', port=5000, debug=True)
