import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'patel_mobiles.db')

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Create products table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            category TEXT NOT NULL,
            name TEXT NOT NULL UNIQUE,
            stock INTEGER NOT NULL DEFAULT 0,
            price REAL NOT NULL DEFAULT 0.0,
            rack_no TEXT,
            box_no TEXT,
            barcode TEXT UNIQUE
        )
    ''')
    
    # Create sales table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS sales (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sale_date TEXT NOT NULL,
            sale_time TEXT NOT NULL,
            customer_name TEXT,
            gst_number TEXT,
            product_id INTEGER,
            product_name TEXT NOT NULL,
            quantity INTEGER NOT NULL,
            price REAL NOT NULL,
            total_price REAL NOT NULL,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
        )
    ''')
    
    # Pre-populate products if empty
    cursor.execute('SELECT COUNT(*) FROM products')
    if cursor.fetchone()[0] == 0:
        initial_mobiles = [
            "RENO 8", "RENO 7 5G", "F19", "F19 PRO", "F19S", "F19 PRO+ 5G", 
            "F21 PRO", "F21S PRO", "REALME X7", "7 PRO", "8", "8 PRO", 
            "9 4G", "9 5G", "9 PRO+", "10 4G", "11", "NARZO 60", 
            "1+NORD CE2 5G", "A78 4G"
        ]
        
        initial_products = []
        for name in initial_mobiles:
            # Determine brand prefixes to make initial barcodes/names nice
            barcode_val = f"BAR-{name.replace(' ', '').replace('+', '')}"
            initial_products.append(('mobiles', name, 10, 15000.0, 'R1', 'B1', barcode_val))
            
        # Add some default cases, temper glass, chargers, earbuds
        initial_products.extend([
            ('cases', 'Reno 8 Silicon Case', 20, 250.0, 'R2', 'B1', 'BAR-CASE1'),
            ('temper glass', 'Realme 11 Tempered Glass', 30, 150.0, 'R3', 'B2', 'BAR-TEMP1'),
            ('uv temper glass', 'Curved Display UV Temper Glass', 15, 450.0, 'R3', 'B3', 'BAR-UV1'),
            ('earbuds', 'OnePlus Nord Buds 2', 8, 2200.0, 'R4', 'B1', 'BAR-BUDS1'),
            ('chargers', 'SuperVOOC 80W Charger', 12, 1800.0, 'R5', 'B2', 'BAR-CHG1'),
            ('repairs', 'Oppo Reno Screen Replacement', 5, 3500.0, 'REP', 'B1', 'BAR-REP1')
        ])
        
        cursor.executemany('''
            INSERT INTO products (category, name, stock, price, rack_no, box_no, barcode)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', initial_products)
        
    conn.commit()
    conn.close()

if __name__ == '__main__':
    init_db()
    print("Database initialized successfully.")
